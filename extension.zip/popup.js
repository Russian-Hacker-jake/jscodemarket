var editor = CodeMirror.fromTextArea(document.getElementById('code'), {
    lineNumbers: true,
    matchBrackets: true,
    mode: "text/javascript",
    indentUnit: 4,
    indentWithTabs: true,
    autoCloseBrackets: true,
    autoCloseTags: true,
    autoRefresh: true,
    theme: "rubyblue",
    extraKeys: {"Ctrl-Space": "autocomplete"},
    hintOptions: {tables: {
        users: {name: null, score: null, birthDate: null},
        countries: {name: null, population: null, size: null}
    }}
  });
    editor.setSize("500px", "500px");
function run()
{
    var code = editor.getValue();
    if(code.length > 0)
    {
        document.getElementById('result') + chrome.tabs.executeScript(null, {code: code});
        document.getElementById('result').style = "display: block";
    }
    else{
        alert("Please enter some code");
    }
  }
function clear()
{
    editor.setValue("");
    document.getElementById('result').style = "display: none";
    document.getElementById('script-list').style = "display: none";
}
document.getElementById('run').onclick = run;
document.getElementById('clear').onclick = clear;
document.getElementById('save').onclick = function()
{
    var code = editor.getValue();
    var name = prompt("Enter the name of the script");
    if(name.length > 0)
    {
        if(code.length > 0)
        {
            chrome.storage.local.set({[name]: code}, function()
            {
                alert("Saved");
            });
        }
        else{
            alert("Please enter some code");
        }
    }
    else{
        alert("Please enter a name");
    }
}
document.getElementById('loadscript').onclick = function()
{
    var name = prompt("Enter the name of the script");
    if(name.length > 0)
    {
        //check if the result is undefined
        chrome.storage.local.get([name], function(result)
        {
            if(result[name] != undefined)
            {
                editor.setValue(result[name]);
            }
            else{
                alert("No script with that name");
            }
        });
    }
    else{
        alert("Please enter a name");
    }
}
document.getElementById('deletescript').onclick = function()
{
    var name = prompt("Enter the name of the script");
    if(name.length > 0)
    {
       //check if name exists in local storage
       chrome.storage.local.get([name], function(result)
         {
              if(result[name] != undefined)
              {
                chrome.storage.local.remove(name, function()
                {
                     alert("Deleted");
                });
              }
              else{
                alert("No script with that name");
              }
         });
}
window.onbeforeunload = function()
{
    var code = editor.getValue();
    if(code.length > 0)
    {
       return "Do you want to save the code?";
    }
}
}
document.getElementById('savedscripts').onclick = function()
{
    chrome.storage.local.get(null, function(result)
    {
        var keys = Object.keys(result);
        var scriptlist = "";
        for(var i = 0; i < keys.length; i++)
        {
        scriptlist += keys[i] + "\n";;
        document.getElementById('script-list').innerHTML = "script-name" +" "+ scriptlist + "<br>";
        document.getElementById('script-list').style = "display: block";
        }
    });
}
document.getElementById('view-market').onclick = function()
{
  //redirect to https://jscodemarket.github.com/
  chrome.tabs.create({url: "https://russian-hacker-jake.github.io/jscodemarket"});
}